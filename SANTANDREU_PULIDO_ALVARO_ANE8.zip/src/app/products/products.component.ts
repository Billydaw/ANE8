import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent {

  @Input() codigoProducto='666';
  @Input() nombre='Collar Pentágono';
  @Input() descripcion='Colgante con el símbolo de un pentágono';
  @Input() precio='666€';
  @Input() stock='666';
  @Input() img='https://picsum.photos/seed/picsum/200/300';

}
